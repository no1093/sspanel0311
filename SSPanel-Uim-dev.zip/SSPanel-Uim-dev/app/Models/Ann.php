<?php

namespace App\Models;

/**
 * Ann Model
 */
class Ann extends Model
{
    protected $connection = 'default';
    protected $table = 'announcement';
}
