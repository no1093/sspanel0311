<?php

namespace App\Models;

class RadiusRadCheck extends Model
{
    protected $connection = 'radius';
    protected $table = 'radcheck';
}
