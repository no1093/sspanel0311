<?php

namespace App\Models;

/**
 * DetectLog Model
 */
class DetectRule extends Model
{
    protected $connection = 'default';
    protected $table = 'detect_list';
}
