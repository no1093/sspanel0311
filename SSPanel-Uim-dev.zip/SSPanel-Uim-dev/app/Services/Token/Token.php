<?php


namespace App\Services\Token;

class Token
{
    public $token;
    public $userId;
    public $createTime;
    public $expireTime;
}
